def test(s):
	return

