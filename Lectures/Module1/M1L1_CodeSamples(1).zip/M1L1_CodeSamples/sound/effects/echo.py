def echofilter(input, output):
	return

