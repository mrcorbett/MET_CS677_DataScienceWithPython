def read(inp):
	return

