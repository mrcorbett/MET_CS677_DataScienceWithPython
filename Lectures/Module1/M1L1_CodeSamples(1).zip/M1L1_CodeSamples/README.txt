Running the Code Samples

cd <current folder with code samples>

jupyter notebook

 - Select the appropriate notebook

 